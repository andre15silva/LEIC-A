#!/bin/bash
java -Xmx5000m -jar target/assignment4-jabeja-1.0-jar-with-dependencies.jar $@
