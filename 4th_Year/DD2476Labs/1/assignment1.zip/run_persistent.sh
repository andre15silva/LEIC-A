#!/bin/sh
java -cp classes -Xmx1g ir.Engine -d /info/DD2476/ir20/lab/davisWiki -l ir20.png -p patterns.txt -ni
